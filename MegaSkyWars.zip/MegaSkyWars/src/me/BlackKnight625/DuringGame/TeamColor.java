package me.BlackKnight625.DuringGame;

public enum TeamColor {
	GREEN, YELLOW, RED, BLUE, WHITE, BLACK, LIME, ORANGE, MAGENTA, LIGHT_BLUE, LIGHT_GRAY, GRAY, CYAN, PURPLE
}
