package me.BlackKnight625.MegaSkyWars;

public class Map {

}
